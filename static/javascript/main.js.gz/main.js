$('.alert').alert()

$('.collapse').collapse()

$('#collapseExample').collapse({
  toggle: true
})